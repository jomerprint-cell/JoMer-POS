DULAUGONPOS 8.21 - GITHUB CHECK FOR UPDATE

NADUGANG:
- Check for Update button inside Backup / Settings.
- Save GitHub Repo input (username/repository).
- Checks GitHub's latest published Release.
- Compares release tag against installed 8.21.0.
- Download Update button appears if release is newer.
- Works in HTML, Portable source and Installer source.

LIMITASYON:
- Wala pa'y GitHub account/repository supplied, so enter it in the app.
- GitHub Release must be PUBLIC, published, and versioned e.g. v8.22.0.
- Check and download ONLY; installation is NOT automatic.
- DULAUGON UPDATE.exe is not included as a compiled binary.
- Portable and Installer source require Windows build (Node.js + electron-builder).
- Export POS backup before updating. Check compatibility with your old local data.

GITHUB SETUP: basaha ang GitHubRelease/README-BISAYA.txt.
