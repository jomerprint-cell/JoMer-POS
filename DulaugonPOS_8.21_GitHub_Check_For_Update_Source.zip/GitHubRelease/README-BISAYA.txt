GITHUB UPDATE - DULAUGONPOS

1. Create a PUBLIC GitHub repository named DulaugonPOS (or your chosen name).
2. Sa POS > Backup / Settings, isulod ang username/repository ug click Save GitHub Repo.
3. Sa GitHub repository, open Releases > Draft a new release.
4. Tag: v8.22.0 (kinahanglan mas bag-o sa 8.21.0).
5. I-attach ang tested DulaugonPOS-Update-v8.22.0.zip nga adunay actual app update files.
6. Publish release. Sa POS, click Check for Update.
7. Kung naay bag-o, makita ang Download Update button.

IMPORTANT: Check for Update ONLY checks published GitHub Releases and offers a download link. It DOES NOT install the update automatically. A Windows updater must still apply the downloaded ZIP. The current older DULAUGON UPDATE.exe is NOT compatible with arbitrary GitHub ZIPs.
Never upload customer records, passwords, backups, or private data to a public GitHub repo.
This project contains the HTML and Electron build source. The Portable/Installer EXEs have not been compiled here.
