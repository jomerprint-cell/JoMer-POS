@echo off
title DulaugonPOS 8.21 Portable Builder
cd /d "%~dp0"
echo ==========================================
echo   DULAUGON POS 8.21 - PORTABLE BUILDER
echo ==========================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install Node.js LTS first.
  echo https://nodejs.org/
  pause
  exit /b 1
)
echo Installing required packages...
call npm install
if errorlevel 1 (
  echo Package installation failed.
  pause
  exit /b 1
)
echo Building portable EXE...
call npm run dist
if errorlevel 1 (
  echo Build failed. Please check the error above.
  pause
  exit /b 1
)
echo.
echo BUILD COMPLETE.
if exist "dist\DulaugonPOS-8.21-AppData-Portable.exe" (
  if not exist "..\..\Payload\Portable" mkdir "..\..\Payload\Portable"
  copy /Y "dist\DulaugonPOS-8.21-AppData-Portable.exe" "..\..\Payload\Portable\DulaugonPOS-8.21-AppData-Portable.exe" >nul
  echo Portable EXE copied automatically to Payload\Portable.
) else (
  echo WARNING: Portable EXE not found. Check the dist folder.
)
pause
