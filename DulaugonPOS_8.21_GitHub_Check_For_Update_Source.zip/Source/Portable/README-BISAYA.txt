DULAUGON POS 8.20 - PORTABLE APPLICATION
=========================================

UNSA ANG APIL
- Latest HTML nga imong gi-upload.
- Imong bag-ong Blacksmith ICO logo: gigamit sa login/header ug Windows app icon.
- Right-click menu: Undo, Redo, Cut, Copy, Paste, Delete, Select All.
- Ctrl+C, Ctrl+V, Ctrl+X ug Ctrl+A shortcuts.
- POS data/profile ibutang sa:
  %APPDATA%\DulaugonPOS-Data

PAGHIMO SA PORTABLE EXE (KINAHANGLAN WINDOWS PC)
1. I-extract ang ZIP ngadto sa usa ka folder.
2. I-install ang Node.js LTS gikan sa https://nodejs.org/
3. Siguroa nga naay internet sa unang build.
4. Double-click ang build-portable.bat.
5. Hulata mahuman. Ang EXE makita sulod sa dist folder.

COPY/PASTE SA PASSWORD
- I-right-click sulod sa password box ug pilia ang Paste.
- Pwede usab Ctrl+V.
- Ang Copy/Cut sa password field mosunod sa browser security rules; ang hidden password text dili mahimong kopyahon gikan sa password box. Ang pag-paste ngadto sa password box supported.

IMPORTANTENG BACKUP
Ang browser localStorage data sa daan nga browser dili automatic nga mobalhin sa bag-ong Electron AppData profile.
I-export/backup una ang daan nimong POS records.
Sa umaabot, i-backup ang:
%APPDATA%\DulaugonPOS-Data

NOTE
Ang ZIP mao ang source project. Wala pa ma-build o ma-test ang Windows EXE dinhi.
Kinahanglan ipadagan ang build-portable.bat sa Windows PC.
