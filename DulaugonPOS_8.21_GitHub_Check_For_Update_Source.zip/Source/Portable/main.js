const { app, BrowserWindow, Menu, shell, clipboard } = require('electron');
const path = require('path');

const dataDirectory = path.join(app.getPath('appData'), 'DulaugonPOS-Data');
app.setPath('userData', dataDirectory);

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 980,
    minHeight: 680,
    show: false,
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'assets', 'dulaugon-blacksmith.ico'),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.once('ready-to-show', () => mainWindow.show());

  // Native Windows editing menu. Paste is available in password inputs too.
  mainWindow.webContents.on('context-menu', (_event, params) => {
    const editable = params.isEditable;
    const hasSelection = Boolean(params.selectionText);
    const menuItems = [];

    if (editable) {
      menuItems.push(
        { role: 'undo', label: 'Undo' },
        { role: 'redo', label: 'Redo' },
        { type: 'separator' },
        { role: 'cut', label: 'Cut', enabled: params.editFlags.canCut },
        { role: 'copy', label: 'Copy', enabled: params.editFlags.canCopy },
        { role: 'paste', label: 'Paste', enabled: clipboard.readText().length > 0 },
        { role: 'delete', label: 'Delete' },
        { type: 'separator' },
        { role: 'selectAll', label: 'Select All' }
      );
    } else if (hasSelection) {
      menuItems.push(
        { role: 'copy', label: 'Copy' },
        { role: 'selectAll', label: 'Select All' }
      );
    }

    if (menuItems.length) {
      Menu.buildFromTemplate(menuItems).popup({ window: mainWindow });
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url === 'about:blank') return { action: 'allow' };
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.whenReady().then(() => {
  // Keep standard Edit shortcuts/menu roles available.
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' }, { role: 'redo' }, { type: 'separator' },
        { role: 'cut' }, { role: 'copy' }, { role: 'paste' },
        { role: 'delete' }, { type: 'separator' }, { role: 'selectAll' }
      ]
    }
  ]));
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
