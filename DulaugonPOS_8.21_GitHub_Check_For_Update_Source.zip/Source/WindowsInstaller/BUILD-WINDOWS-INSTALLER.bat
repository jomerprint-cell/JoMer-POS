@echo off
title Build DulaugonPOS 8.21 Windows Installer
cd /d "%~dp0"
echo ==========================================
echo   DULAUGONPOS VERSION 8.21 - INSTALLER
echo ==========================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js LTS is not installed. Install it from https://nodejs.org/
  pause
  exit /b 1
)
echo Installing required packages...
call npm install
if errorlevel 1 (
  echo Package installation failed.
  pause
  exit /b 1
)
echo Building Windows Setup.exe...
call npm run dist
if errorlevel 1 (
  echo Build failed. Please check the error above.
  pause
  exit /b 1
)
echo.
echo SUCCESS!
if exist "dist\DulaugonPOS-8.21-Setup.exe" (
  if not exist "..\..\Payload\Installer" mkdir "..\..\Payload\Installer"
  copy /Y "dist\DulaugonPOS-8.21-Setup.exe" "..\..\Payload\Installer\DulaugonPOS-8.21-Setup.exe" >nul
  echo Installer copied automatically to Payload\Installer.
) else (
  echo WARNING: Installer EXE not found. Check the dist folder.
)
pause
