DULAUGONPOS VERSION 8.20 - WINDOWS INSTALLER SOURCE

UNSAY PAGHIMO SA SETUP.EXE:
1. I-extract ang ZIP file.
2. Siguroa nga naka-install ang Node.js LTS sa Windows computer.
3. Double-click ang BUILD-WINDOWS-INSTALLER.bat.
4. Hulata nga mahuman ang npm install ug Windows build.
5. Ablihi ang dist folder. Didto makita ang DulaugonPOS Setup.exe.
6. I-run ang Setup.exe aron ma-install ang POS.

MGA GI-APPLY:
- Version sa installer: 8.20.0.
- Ang index.html mao ang eksaktong kopya sa imong gi-upload nga Version 8.20 file; wala gi-edit ang POS page.
- Ang app, installer, uninstaller ug desktop shortcut naggamit sa app.ico nga gihimo gikan sa embedded logo sa imong HTML.
- Ang right-click context menu adunay Copy / Copy password, Paste, Cut ug Select All sa editable fields.
- Ang password Copy password action mokopya sa selected text; kung walay selection, mokopya sa tibuok password field value.
- App ID nagpabilin aron mailhan sa Windows isip samang DulaugonPOS application.

IMPORTANTE:
Kini source package pa; wala pa ma-build o ma-test ang actual Setup.exe sa Windows dinhi.
Kung naa nay daan nga DulaugonPOS, i-uninstall una ang daan nga version ug tangtanga ang daan nga desktop shortcut sa dili pa i-install ang bag-o aron malikayan ang cached old icon.
