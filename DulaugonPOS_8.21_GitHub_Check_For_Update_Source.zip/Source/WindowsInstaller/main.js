const { app, BrowserWindow, Menu, clipboard } = require('electron');
const path = require('path');

const APP_ID = 'com.jomer.dulaugonpos';
app.setAppUserModelId(APP_ID);

function createWindow() {
  const win = new BrowserWindow({
    width: 1366,
    height: 900,
    minWidth: 900,
    minHeight: 650,
    show: false,
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'assets', 'app.ico'),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: true
    }
  });

  win.loadFile(path.join(__dirname, 'index.html'));
  win.once('ready-to-show', () => win.show());

  win.webContents.on('context-menu', async (_event, params) => {
    const isEditable = params.isEditable;
    const isPassword = params.inputFieldType === 'password';
    const hasSelection = params.selectionText && params.selectionText.length > 0;
    const menu = [];

    if (isEditable) {
      menu.push({ label: 'Cut', enabled: params.editFlags.canCut, click: () => win.webContents.cut() });
      menu.push({
        label: isPassword ? 'Copy password' : 'Copy',
        enabled: isPassword || params.editFlags.canCopy || hasSelection,
        click: async () => {
          try {
            const selectedOrValue = await win.webContents.executeJavaScript(`(() => {
              const el = document.activeElement;
              if (!el) return '';
              if (el.matches('input, textarea')) {
                const start = el.selectionStart ?? 0;
                const end = el.selectionEnd ?? 0;
                if (end > start) return el.value.slice(start, end);
                return el.value || '';
              }
              return window.getSelection()?.toString() || '';
            })()`);
            if (selectedOrValue) clipboard.writeText(selectedOrValue);
            else win.webContents.copy();
          } catch (_) { win.webContents.copy(); }
        }
      });
      menu.push({
        label: 'Paste',
        enabled: true,
        click: async () => {
          const value = clipboard.readText();
          if (!value) return;
          await win.webContents.executeJavaScript(`(() => {
            const el = document.activeElement;
            if (el && (el.matches('input, textarea'))) {
              const start = el.selectionStart ?? el.value.length;
              const end = el.selectionEnd ?? el.value.length;
              el.setRangeText(${JSON.stringify(value)}, start, end, 'end');
              el.dispatchEvent(new Event('input', { bubbles: true }));
              el.dispatchEvent(new Event('change', { bubbles: true }));
            } else if (el && el.isContentEditable) {
              document.execCommand('insertText', false, ${JSON.stringify(value)});
            }
          })()`);
        }
      });
      menu.push({ type: 'separator' });
      menu.push({ label: 'Select All', click: () => win.webContents.selectAll() });
    } else if (hasSelection) {
      menu.push({ label: 'Copy', click: () => win.webContents.copy() });
      menu.push({ label: 'Select All', click: () => win.webContents.selectAll() });
    }

    if (menu.length) Menu.buildFromTemplate(menu).popup({ window: win });
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
