Updater source with GitHub Check for Update.
1. Double click BUILD-ONECLICK-UPDATER.bat on Windows to compile.
2. Enter GitHub username/repository and click Check for Update.
3. When newer release found, opens GitHub Release page.
4. Existing HTML/Portable/Installer buttons use Payload folder, which is NOT included in this UpdaterSource folder.
5. GitHub button DOES NOT auto-install the release. Use the downloaded files with a compatible updater after backup.
6. Windows .NET Framework compiler required; not compiled/tested here.
