using System;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
using System.Net;
using System.Text.RegularExpressions;

static class DulaugonUpdater
{
    static string Root = AppDomain.CurrentDomain.BaseDirectory;
    static string BackupRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "DulaugonPOS-Backups");
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Directory.CreateDirectory(BackupRoot);
        string[] choices = { "HTML Application", "Portable Application (EXE)", "Windows Installer Application (Setup.exe)" };
        using (Form f = new Form())
        {
            f.Text = "DulaugonPOS 8.21 - GitHub Universal Updater"; f.Width = 540; f.Height = 405; f.StartPosition = FormStartPosition.CenterScreen;
            Label title = new Label(); title.Text = "DULAUGONPOS 8.20\r\nOFFLINE ONE-CLICK UPDATER"; title.AutoSize = false; title.Left = 24; title.Top = 18; title.Width = 450; title.Height = 55; title.Font = new System.Drawing.Font("Segoe UI", 15, System.Drawing.FontStyle.Bold);
            Label note = new Label(); note.Text = "Pilia ang klase sa application nga imong i-update. Maghimo una og backup."; note.Left = 26; note.Top = 82; note.Width = 450; note.Height = 36;
            Button html = MakeButton("1. HTML Application", 26, 128);
            Button portable = MakeButton("2. Portable Application", 26, 168);
            Button installer = MakeButton("3. Windows Installer", 26, 208);
            html.Click += (s,e) => { f.Hide(); UpdateHtml(); f.Close(); };
            portable.Click += (s,e) => { f.Hide(); UpdatePortable(); f.Close(); };
            installer.Click += (s,e) => { f.Hide(); UpdateInstaller(); f.Close(); };
            Label repoLabel = new Label { Text="GitHub repository (username/repository):", Left=26, Top=252, Width=440, Height=20 };
            TextBox repo = new TextBox { Left=26, Top=275, Width=310, Text=LoadRepo() };
            Button check = new Button { Text="Check for Update", Left=345, Top=273, Width=150, Height=28 };
            Label result = new Label { Text="Internet required for GitHub check. Manual Payload updates still supported.", Left=26, Top=311, Width=475, Height=50 };
            check.Click += (s,e) => {
                string r=repo.Text.Trim();
                if(!Regex.IsMatch(r,@"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")){result.Text="Invalid repository. Use username/repository.";return;}
                File.WriteAllText(Path.Combine(Root,"github-repo.txt"),r);
                try {
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                    using(var wc=new WebClient()){
                        wc.Headers.Add("User-Agent","DulaugonPOS-Updater");
                        wc.Headers.Add("Accept","application/vnd.github+json");
                        string response=wc.DownloadString("https://api.github.com/repos/"+r+"/releases/latest");
                        var tag=Regex.Match(response, @"\u0022tag_name\u0022\s*:\s*\u0022([^\u0022]+)\u0022");
                        if(!tag.Success){result.Text="Release version not found.";return;}
                        string latest=tag.Groups[1].Value;
                        result.Text="Installed: 8.21.0 | Latest: "+latest;
                        if(IsNewer(latest,"8.21.0")){
                            if(MessageBox.Show("New release "+latest+" found. Open GitHub Releases page to download the update?","Update available",MessageBoxButtons.YesNo)==DialogResult.Yes)
                                Process.Start("https://github.com/"+r+"/releases/latest");
                        } else MessageBox.Show("Up to date or release is not newer than v8.21.0.");
                    }
                } catch(Exception ex){result.Text="GitHub check failed: "+ex.Message;}
            };
            f.Controls.AddRange(new Control[]{title,note,html,portable,installer,repoLabel,repo,check,result}); Application.Run(f);
        }
    }
    static string LoadRepo(){try{string p=Path.Combine(Root,"github-repo.txt");return File.Exists(p)?File.ReadAllText(p).Trim():"";}catch{return "";}}
    static bool IsNewer(string latest,string current){
        try{
            Version a=new Version(Regex.Match(latest,@"\d+(?:\.\d+){0,3}").Value);
            Version b=new Version(current);
            return a.CompareTo(b)>0;
        }catch{return false;}
    }
    static Button MakeButton(string text, int x, int y) { return new Button { Text=text, Left=x, Top=y, Width=445, Height=34, Font=new System.Drawing.Font("Segoe UI",10) }; }
    static string Stamp() { return DateTime.Now.ToString("yyyyMMdd-HHmmss"); }
    static void Info(string s) { MessageBox.Show(s, "DulaugonPOS Updater", MessageBoxButtons.OK, MessageBoxIcon.Information); }
    static void Fail(string s) { MessageBox.Show(s, "DulaugonPOS Updater", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    static void CopyDir(string src, string dst) { if (!Directory.Exists(src)) return; Directory.CreateDirectory(dst); foreach(string d in Directory.GetDirectories(src,"*",SearchOption.AllDirectories)){Directory.CreateDirectory(d.Replace(src,dst));} foreach(string file in Directory.GetFiles(src,"*",SearchOption.AllDirectories)){string to=file.Replace(src,dst);Directory.CreateDirectory(Path.GetDirectoryName(to));File.Copy(file,to,true);} }
    static void BackupAppData(string label) { string stamp=Stamp(); string[] paths={Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"DulaugonPOS"),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"dulaugonpos"),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"dulaugon-blacksmith-pos"),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"DulaugonPOS-Data")}; foreach(string p in paths) if(Directory.Exists(p)) CopyDir(p,Path.Combine(BackupRoot,label+"-"+stamp,Path.GetFileName(p))); }
    static string PickFolder(string desc) { using(FolderBrowserDialog d=new FolderBrowserDialog()){d.Description=desc;return d.ShowDialog()==DialogResult.OK?d.SelectedPath:null;} }
    static string PickFile(string title,string filter) { using(OpenFileDialog d=new OpenFileDialog()){d.Title=title;d.Filter=filter;return d.ShowDialog()==DialogResult.OK?d.FileName:null;} }
    static void UpdateHtml()
    {
        string payload=Path.Combine(Root,"Payload","HTML","DulaugonPOS-8.21.html"); if(!File.Exists(payload)){Fail("Wala ang HTML update payload.");return;}
        string old=PickFile("Pilia ang kasamtangang HTML POS file nga ilisan","HTML files (*.html)|*.html"); if(old==null)return;
        if(MessageBox.Show("I-update ang:\r\n"+old+"\r\n\r\nMaghimo una og backup. Padayon?","Confirm HTML Update",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
        string backup=Path.Combine(BackupRoot,"HTML-"+Stamp());Directory.CreateDirectory(backup);File.Copy(old,Path.Combine(backup,Path.GetFileName(old)),true);
        string temp=old+".new";File.Copy(payload,temp,true);File.Copy(temp,old,true);File.Delete(temp);
        Info("HTML update nahuman. Ang daang HTML gi-backup sa Documents\\DulaugonPOS-Backups. Ablihi pag-usab ang parehas nga HTML file.");
    }
    static void UpdatePortable()
    {
        string payload=Path.Combine(Root,"Payload","Portable","DulaugonPOS-8.21-AppData-Portable.exe"); if(!File.Exists(payload)){Fail("Wala pa ang Portable EXE payload. I-build una ang Portable project sulod sa Source\\Portable, unya ibutang ang EXE sa Payload\\Portable nga ngalan DulaugonPOS-8.21-AppData-Portable.exe.");return;}
        string dir=PickFolder("Pilia ang folder diin naa ang kasamtangang Portable EXE ug DulaugonPOS-Data folder");if(dir==null)return;
        string old=Path.Combine(dir,"DulaugonPOS-8.21-AppData-Portable.exe");
        if(!File.Exists(old)) {
            string[] exes=Directory.GetFiles(dir,"*Portable*.exe");
            if(exes.Length==0){Fail("Wala makit-i ang Portable EXE sa gipiling folder. Siguroa nga naa ang DulaugonPOS-8.21-AppData-Portable.exe.");return;}
            old=exes[0];
        }
        if(MessageBox.Show("Ilisan ang:\r\n"+old+"\r\n\r\nDili hilabtan ang DulaugonPOS-Data folder. Padayon?","Confirm Portable Update",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
        string b=Path.Combine(BackupRoot,"Portable-"+Stamp());Directory.CreateDirectory(b);File.Copy(old,Path.Combine(b,Path.GetFileName(old)),true);// The portable build stores its persistent POS profile under %APPDATA%\\DulaugonPOS-Data.
        string data=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"DulaugonPOS-Data");
        if(Directory.Exists(data)) CopyDir(data,Path.Combine(b,"DulaugonPOS-Data"));
        // Also preserve a legacy data folder beside the portable EXE, if present.
        string localData=Path.Combine(dir,"DulaugonPOS-Data");
        if(Directory.Exists(localData)) CopyDir(localData,Path.Combine(b,"Portable-Local-DulaugonPOS-Data"));
        // Replace the existing EXE in-place so existing shortcuts continue to work.
        string target=old;
        string staging=target+".update-new";
        File.Copy(payload,staging,true);
        try { File.Copy(staging,target,true); File.Delete(staging); }
        catch { try { if(File.Exists(staging)) File.Delete(staging); } catch {} throw new Exception("Dili ma-ilisan ang Portable EXE. Sirad-a una ang POS ug sulayi pag-usab."); }
        Info("Portable update nahuman. Gi-preserve ang POS data sa %APPDATA%\\DulaugonPOS-Data. Backup naa sa Documents\\DulaugonPOS-Backups.");
    }
    static void UpdateInstaller()
    {
        string setup=Path.Combine(Root,"Payload","Installer","DulaugonPOS-8.21-Setup.exe");if(!File.Exists(setup)){Fail("Wala pa ang Setup.exe payload. I-build una ang WindowsInstaller project ug ibutang ang Setup.exe sa Payload\\Installer nga ngalan DulaugonPOS-8.21-Setup.exe.");return;}
        if(MessageBox.Show("Sirad-a una ang POS. Mag-backup sa AppData ug i-launch ang Setup.exe. Padayon?","Confirm Installer Update",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
        BackupAppData("Installer-AppData"); Process.Start(setup);Info("Gi-launch ang installer. Sunda ang installation steps. Ayaw i-uninstall una ang daang POS.");
    }
}
