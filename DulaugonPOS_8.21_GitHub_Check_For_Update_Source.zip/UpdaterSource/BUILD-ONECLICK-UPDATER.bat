@echo off
setlocal
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
 echo WALA MAKIT-I ANG .NET Framework C# compiler.
 echo Install .NET Framework 4.8 Developer Pack o Visual Studio Build Tools, unya sulayi pag-usab.
 pause
 exit /b 1
)
if not exist "Payload\HTML" mkdir "Payload\HTML"
if not exist "Payload\Portable" mkdir "Payload\Portable"
if not exist "Payload\Installer" mkdir "Payload\Installer"
"%CSC%" /nologo /target:winexe /out:"DULAUGON UPDATE.exe" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll DulaugonUpdater.cs
if errorlevel 1 (echo BUILD FAILED.& pause & exit /b 1)
echo.
echo Nahimo na ang DULAUGON UPDATE.exe.
echo Ibilin kini sa parehas nga folder sa Payload folder.
pause
